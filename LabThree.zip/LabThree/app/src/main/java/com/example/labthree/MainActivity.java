package com.example.labthree;

import static com.example.labthree.R.*;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity  {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.activity_main);

    }
     public void Add(View v){
        EditText et1 = (EditText)findViewById(id.num1);
         EditText et2 = (EditText)findViewById(id.num2);
         TextView et3 = (TextView)findViewById(id.result);

         int n1 = Integer.parseInt(et1.getText().toString());
         int n2 = Integer.parseInt(et2.getText().toString());
         int re = n1+n2;

         et3.setText("Answer = "+re);
    }

    public void Sub(View v){
        EditText et1 = (EditText)findViewById(id.num1);
        EditText et2 = (EditText)findViewById(id.num2);
        TextView et3 = (TextView)findViewById(id.result);

        int n1 = Integer.parseInt(et1.getText().toString());
        int n2 = Integer.parseInt(et2.getText().toString());
        int re = n1-n2;

        et3.setText("Answer = "+re);
    }

    public void Mult(View v){
        EditText et1 = (EditText)findViewById(id.num1);
        EditText et2 = (EditText)findViewById(id.num2);
        TextView et3 = (TextView)findViewById(id.result);

        int n1 = Integer.parseInt(et1.getText().toString());
        int n2 = Integer.parseInt(et2.getText().toString());
        int re = n1*n2;

        et3.setText("Answer = "+re);
    }

    public void div(View v){
        EditText et1 = (EditText)findViewById(id.num1);
        EditText et2 = (EditText)findViewById(id.num2);
        TextView et3 = (TextView)findViewById(id.result);

        int n1 = Integer.parseInt(et1.getText().toString());
        int n2 = Integer.parseInt(et2.getText().toString());
        int re = n1/n2;

        et3.setText("Answer = "+re);
    }
       }





    /*public boolean getNumbers()
    {
        e1 = (EditText) findViewById (R.id.num1);
        e2 = (EditText) findViewById (R.id.num2);
        t1 = (TextView) findViewById (R.id.result);
        String s1, s2;

        s1 = e1.getText().toString();
        s2 = e2.getText().toString();

        if((s1.equals(null) && s2.equals(null)) || (s1.equals("") && s2.equals(""))) {
            String result = "Please enter a value";
            t1.setText(result);
            return false;
        }
        else {
            num1 = Integer.parseInt(e1.getText().toString());
            num2 = Integer.parseInt(e2.getText().toString());
        }
        return true;
    }
    public void dosum(View v){
        if (getNumbers()){
            int sum = num1 + num2;
            t1.setText(Integer.toString(sum));
        }
    }

    public void dosub(View v){
        if(getNumbers()){
            int sum = num1-num2;
            t1.setText(Integer.toString(sum));
        }
    }
*/
